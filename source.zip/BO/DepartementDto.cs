﻿namespace BO
{
    public class DepartementDto
    {
        public string DepartementId { get; set; }
        public string Libelle { get; set; }
        public int RegionId { get; set; }
    }
}
