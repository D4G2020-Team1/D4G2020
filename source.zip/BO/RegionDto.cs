﻿namespace BO
{
    public class RegionDto
    {
        public int RegionId { get; set; }
        public string Libelle { get; set; }
    }
}
