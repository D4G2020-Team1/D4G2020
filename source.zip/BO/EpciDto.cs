﻿namespace BO
{
    public class EpciDto
    {
        public string EpciId { get; set; }
        public string Libelle { get; set; }
        public string DepartementId { get; set; }
    }
}
