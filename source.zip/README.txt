Team 1

This project is developped with .NET Core Backend, Angular Frontend and MySQL database.