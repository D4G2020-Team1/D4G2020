export class Region {
    regionId: number;
    libelle: string;
}
