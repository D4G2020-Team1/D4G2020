"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Commune = void 0;
var Commune = /** @class */ (function () {
    function Commune() {
    }
    return Commune;
}());
exports.Commune = Commune;
//# sourceMappingURL=commune.js.map