"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Score = void 0;
var Score = /** @class */ (function () {
    function Score() {
    }
    return Score;
}());
exports.Score = Score;
//# sourceMappingURL=score.js.map