import { Score } from './score';

export class Commune {

    codeInsee: string;
    nomCommune: string
    codePostal: string;

    scores: Score[];
}
