export class Epci {
    epciId: string;
    libelle: string;
    departementId: string;
}
