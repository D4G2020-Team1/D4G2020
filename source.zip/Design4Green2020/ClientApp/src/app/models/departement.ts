export class Departement {
    departementId: string;
    libelle: string;
    regionId: number;
}
