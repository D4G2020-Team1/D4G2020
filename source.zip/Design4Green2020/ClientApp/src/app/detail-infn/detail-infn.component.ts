import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-infn',
  templateUrl: './detail-infn.component.html',
  styleUrls: ['./detail-infn.component.scss']
})
export class DetailInfnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
